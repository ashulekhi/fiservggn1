import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http"
let getproductsapi = "https://ashuapi.herokuapp.com/api/allproducts"
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(private http:HttpClient) {
    this.http.get(getproductsapi).subscribe((response)=>{
      console.log("products received", response["data"])
    },
  (error)=>{
    console.log("error in getting products",error)
  })
   }

  ngOnInit() {
    
  }

}
